(function(){
  document.addEventListener('DOMContentLoaded', function(){
    var root = document.querySelector('.kdsu-root');
    if (!root) return;
    console.log('[YooKDS] init', {
      theme: root.getAttribute('data-theme'),
      initial: root.getAttribute('data-initial')
    });
  });
})();
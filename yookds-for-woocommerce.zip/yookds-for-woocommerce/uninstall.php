<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Placeholder for cleanup.

<?php
namespace YooKDS;
if (!defined('ABSPATH')) exit;

class Plugin {
    public function init(){
        (new Assets())->init();
        (new Admin())->init();
        (new Shortcodes())->init();
        (new Rest())->init();
    }
}

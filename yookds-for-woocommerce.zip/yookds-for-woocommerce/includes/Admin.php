<?php
namespace YooKDS;
if (!defined('ABSPATH')) exit;

class Admin {
    public function init(){
        add_action('admin_menu', array($this, 'menu'), 99);
    }
    public function menu(){
        add_submenu_page(
            'woocommerce',
            __('YooKDS', 'yookds'),
            __('YooKDS', 'yookds'),
            'manage_options',
            'yookds',
            array($this, 'render_page')
        );
    }
    public function render_page(){
        ?>
        <div class="wrap">
          <h1>YooKDS</h1>
          <p>Admin placeholder. Settings will live here (Stations, Channels, QR, BizPrint, API keys, etc.).</p>
          <p>REST health: <code>/wp-json/yookds/v1/health</code></p>
        </div>
        <?php
    }
}

<?php
namespace YooKDS;
if (!defined('ABSPATH')) exit;

class Assets {
    public function init(){
        add_action('wp_enqueue_scripts', array($this, 'enqueue_public'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin'));
    }
    public function enqueue_public(){
        wp_register_style('yookds-kds', YOOKDS_PLUGIN_URL.'assets/css/kds.css', array(), YOOKDS_VERSION);
        wp_register_script('yookds-kds', YOOKDS_PLUGIN_URL.'assets/js/kds.js', array('wp-i18n'), YOOKDS_VERSION, true);

        if (apply_filters('yookds_enqueue_assets_globally', false)) {
            wp_enqueue_style('yookds-kds');
            wp_enqueue_script('yookds-kds');
        }
    }
    public function enqueue_admin($hook=''){
        // Enqueue admin assets when needed.
    }
}

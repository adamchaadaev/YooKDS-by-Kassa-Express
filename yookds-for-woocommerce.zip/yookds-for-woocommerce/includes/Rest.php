<?php
namespace YooKDS;
if (!defined('ABSPATH')) exit;

class Rest {
    public function init(){
        add_action('rest_api_init', function(){
            register_rest_route('yookds/v1', '/health', array(
                'methods' => 'GET',
                'permission_callback' => '__return_true',
                'callback' => function(){
                    return array(
                        'ok' => true,
                        'plugin' => 'yookds',
                        'version' => YOOKDS_VERSION,
                        'time' => current_time('mysql')
                    );
                }
            ));
        });
    }
}

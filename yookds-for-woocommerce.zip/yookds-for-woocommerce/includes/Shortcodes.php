<?php
namespace YooKDS;
if (!defined('ABSPATH')) exit;

class Shortcodes {
    public function init(){
        add_shortcode('kds_unified', array($this, 'render_kds'));
    }

    public function render_kds($atts = array()){
        $atts = shortcode_atts(array(
            'theme' => 'light',
            'initial' => 'board',
        ), $atts, 'kds_unified');

        wp_enqueue_style('yookds-kds');
        wp_enqueue_script('yookds-kds');

        ob_start();
        ?>
        <div class="kdsu-root" data-theme="<?php echo esc_attr($atts['theme']); ?>"
             data-initial="<?php echo esc_attr($atts['initial']); ?>">
            <div class="kdsu-topbar">
                <div class="kdsu-brand">YooKDS</div>
                <div class="kdsu-controls"></div>
            </div>
            <div class="kdsu-dashboard">
                <div class="kdsu-widget-strip">
                    <div class="widget">Mini-stats</div>
                    <div class="widget">Chips</div>
                    <div class="widget">Circles</div>
                </div>
                <div class="kdsu-panels">
                    <div class="kdsu-panel kdsu-panel--board" aria-hidden="<?php echo $atts['initial']!=='board' ? 'true':'false'; ?>">
                        <div class="kdsu-list grid"></div>
                    </div>
                    <div class="kdsu-panel kdsu-panel--archive" aria-hidden="<?php echo $atts['initial']!=='archive' ? 'true':'false'; ?>">
                        <div class="kdsu-archive"></div>
                    </div>
                </div>
            </div>
            <div class="kdsu-footer">
                <span class="kdsu-powered">Powered by YooKDS</span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

<?php
/**
 * Plugin Name: YooKDS for WooCommerce
 * Plugin URI: https://orangeagency.se/
 * Description: Structured scaffold for YooKDS (assets, shortcode, admin, REST/AJAX).
 * Author: Ninja Nuts AB
 * Author URI: https://orangeagency.se/
 * Version: 1.0.0
 * License: GPL-2.0-or-later
 * Text Domain: yookds
 * Domain Path: /languages
 */
if (!defined('ABSPATH')) exit;

define('YOOKDS_VERSION', '1.0.0');
define('YOOKDS_PLUGIN_FILE', __FILE__);
define('YOOKDS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('YOOKDS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Simple PSR-4-ish loader for this plugin
spl_autoload_register(function($class){
    if (strpos($class, 'YooKDS\\') === 0) {
        $path = YOOKDS_PLUGIN_DIR . 'includes/' . str_replace(array('YooKDS\\', '\\'), array('', '/'), $class) . '.php';
        if (file_exists($path)) require_once $path;
    }
});

// Boot the plugin
add_action('plugins_loaded', function(){
    (new YooKDS\Plugin())->init();
});

// Activation hook
register_activation_hook(__FILE__, function(){
    if (function_exists('flush_rewrite_rules')) flush_rewrite_rules();
});

// Deactivation hook
register_deactivation_hook(__FILE__, function(){
    if (function_exists('flush_rewrite_rules')) flush_rewrite_rules();
});

=== YooKDS for WooCommerce ===
Contributors: ninjanuts
Tags: kitchen display, kds, woocommerce, orders, kiosk
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html

A structured foundation for YooKDS: shortcode, assets loader, admin page, REST/AJAX scaffolding.

== Description ==
EN: This is a clean scaffold to host YooKDS logic in a proper plugin. It provides:
- [kds_unified] shortcode (theme="light|dark", initial="board|archive").
- Asset loader (CSS/JS) with versioning.
- Admin menu placeholder (WooCommerce → YooKDS).
- REST namespace `yookds/v1` and a `health` route.
- Room for AJAX endpoints.

SV: Ett rent skelett för YooKDS som plugin. Inkluderar shortcode, assets, admin-meny och REST-API-grund.

RU: Стартовый каркас для YooKDS как плагина. Шорткод, подключение ассетов, меню админки и REST-API.

== Installation ==
1. Upload the ZIP via Plugins → Add New → Upload.
2. Activate the plugin.
3. Add `[kds_unified]` to a page.

== Changelog ==
= 1.0.0 =
* Initial scaffold.
